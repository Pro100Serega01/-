﻿using System;
using System.Collections.Generic;

namespace BankApp.Models
{
    public class Customer
    {
        public int CustomerID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public DateTime DateOfBirth { get; set; }

        public string FullName => $"{FirstName} {LastName}";

        // Связь с таблицей Loans (один клиент может иметь несколько кредитов)
        public ICollection<Loan> Loans { get; set; }
    }
}