﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace BankApp.Models
{
    public class Loan
    {

        public int LoanID { get; set; }
        public decimal LoanAmount { get; set; }
        public int LoanTerm { get; set; }
        public decimal InterestRate { get; set; }
        public DateTime LoanStartDate { get; set; }
        public DateTime LoanEndDate { get; set; }
        public int CustomerID { get; set; }
        public int LoanTypeID { get; set; }

        // Связь с таблицей Customer (каждый кредит привязан к одному клиенту)
        public Customer Customer { get; set; }

        // Связь с таблицей LoanType (каждый кредит имеет один тип)
        public LoanType LoanType { get; set; }

        // Связь с таблицей LoanPayments (один кредит может иметь несколько платежей)
        public ICollection<LoanPayment> LoanPayments { get; set; }

        // Связь с таблицей LoanTransactions (один кредит может иметь несколько транзакций)
        public ICollection<LoanTransaction> LoanTransactions { get; set; }
    }
}
