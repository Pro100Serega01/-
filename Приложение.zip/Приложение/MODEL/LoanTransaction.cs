﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BankApp.Models
{
    public class LoanTransaction
    {
        [Key]
        public int TransactionID { get; set; }
        public int LoanID { get; set; }
        public decimal TransactionAmount { get; set; }
        public string TransactionType { get; set; }  // Например, "Погашение", "Платеж по основному долгу"
        public DateTime TransactionDate { get; set; }

        // Связь с таблицей Loan (каждая транзакция привязана к одному кредиту)
        public Loan Loan { get; set; }
    }
}
