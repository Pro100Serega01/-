﻿using System.Data.Entity;


namespace BankApp.Models
{
    public class BankContext : DbContext

    {
        public BankContext() : base("DefaultConnection")
        {
            Database.SetInitializer<BankContext>(null);
        }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<LoanType> LoanTypes { get; set; }
        public DbSet<Loan> Loans { get; set; }
        public DbSet<LoanPayment> LoanPayments { get; set; }
        public DbSet<LoanTransaction> LoanTransactions { get; set; }
    }
}
