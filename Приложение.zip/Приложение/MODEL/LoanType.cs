﻿using System.Collections.Generic;

namespace BankApp.Models
{
    public class LoanType
    {
        public int LoanTypeID { get; set; }
        public string LoanTypeName { get; set; }
        public decimal MaxLoanAmount { get; set; }
        public decimal MinInterestRate { get; set; }
        public decimal MaxInterestRate { get; set; }

        // Связь с таблицей Loans (один тип кредита может быть связан с несколькими кредитами)
        public ICollection<Loan> Loans { get; set; }
    }
}
