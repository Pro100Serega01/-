﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BankApp.Models
{
    public class LoanPayment
    {
        [Key]
        public int PaymentID { get; set; }
        public int LoanID { get; set; }
        public decimal PaymentAmount { get; set; }
        public decimal RemainingBalance { get; set; }
        public DateTime PaymentDate { get; set; }

        // Связь с таблицей Loan (каждый платеж привязан к одному кредиту)
        public Loan Loan { get; set; }
    }
}
