﻿using System;
using System.Linq;
using System.Windows;
using BankApp.Models;
using System.Data.Entity;
using System.Windows.Controls;
using System.Text.RegularExpressions;

namespace BankApp
{
    public partial class MainWindow : Window
    {
        private BankContext db;

        public MainWindow()
        {
            InitializeComponent();
            db = new BankContext();
            db.Customers.Load();
            db.Loans.Load();
            db.LoanPayments.Load();
            db.LoanTransactions.Load();
            db.LoanTypes.Load();


            customersGrid.ItemsSource = db.Customers.Local.ToBindingList();
            loansGrid.ItemsSource = db.Loans.Local.ToBindingList();
            loanTypesGrid.ItemsSource = db.LoanTypes.Local.ToBindingList();


            CustomersComboBox.ItemsSource = db.Customers.Local.ToBindingList();
            CustomersComboBox.DisplayMemberPath = "FullName";
            CustomersComboBox.SelectedValuePath = "CustomerID";


            LoanTypesComboBox.ItemsSource = db.LoanTypes.Local.ToBindingList();
            LoanTypesComboBox.DisplayMemberPath = "LoanTypeName";
            LoanTypesComboBox.SelectedValuePath = "LoanTypeID";
        }

        // Сохранение изменений
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            db.SaveChanges();
        }


        private void AddCustomerButton_Click(object sender, RoutedEventArgs e)
        {
            var newCustomer = new Customer
            {
                FirstName = "Иван",
                LastName = "Иванов",
                Email = "ivan@example.com",
                PhoneNumber = "1234567890",
                Address = "Город, Улица"
            };
            MessageBox.Show("Клиент успешно добавлен успешно добавлен!");
            db.Customers.Add(newCustomer);
            db.SaveChanges();
        }

        // Удаление выбранного клиента
        private void DeleteCustomerButton_Click(object sender, RoutedEventArgs e)
        {
            if (customersGrid.SelectedItems.Count > 0)
            {
                for (int i = 0; i < customersGrid.SelectedItems.Count; i++)
                {
                    var customer = customersGrid.SelectedItems[i] as Customer;
                    if (customer != null)
                    {
                        db.Customers.Remove(customer);
                    }
                }
                db.SaveChanges();
            }
        }

        // Добавление нового кредита
        private void AddLoanButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedCustomer = CustomersComboBox.SelectedItem as Customer;
            var selectedLoanType = LoanTypesComboBox.SelectedItem as LoanType;

            // Валидация данных на ввод
            if (selectedCustomer != null && selectedLoanType != null)
            {
                if (ValidateLoanInputs())
                {
                    var newLoan = new Loan
                    {
                        LoanAmount = Convert.ToDecimal(loanAmountTextBox.Text),
                        LoanTerm = Convert.ToInt32(loanTermTextBox.Text),
                        LoanStartDate = DateTime.Now,
                        LoanEndDate = DateTime.Now.AddMonths(Convert.ToInt32(loanTermTextBox.Text)),
                        InterestRate = Convert.ToDecimal(interestRateTextBox.Text),
                        CustomerID = selectedCustomer.CustomerID,
                        LoanTypeID = selectedLoanType.LoanTypeID
                    };

                    db.Loans.Add(newLoan);
                    db.SaveChanges();
                    MessageBox.Show("Кредит успешно добавлен!");
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите клиента и тип кредита для добавления.");
            }
        }

        // Удаление выбранного кредита
        private void DeleteLoanButton_Click(object sender, RoutedEventArgs e)
        {
            if (loansGrid.SelectedItems.Count > 0)
            {
                for (int i = 0; i < loansGrid.SelectedItems.Count; i++)
                {
                    var loan = loansGrid.SelectedItems[i] as Loan;
                    if (loan != null)
                    {
                        db.Loans.Remove(loan);
                    }
                }
                db.SaveChanges();
            }
        }


        private void SaveLoanButton_Click(object sender, RoutedEventArgs e)
        {
            db.SaveChanges();
        }

        // Проверка правильности ввода данных по кредиту
        private bool ValidateLoanInputs()
        {
            decimal loanAmount;
            int loanTerm;
            decimal interestRate;

            if (string.IsNullOrWhiteSpace(loanAmountTextBox.Text) || !decimal.TryParse(loanAmountTextBox.Text, out loanAmount) || loanAmount <= 0)
            {
                MessageBox.Show("Введите корректную сумму кредита.");
                return false;
            }

            if (string.IsNullOrWhiteSpace(loanTermTextBox.Text) || !int.TryParse(loanTermTextBox.Text, out loanTerm) || loanTerm <= 0)
            {
                MessageBox.Show("Введите корректный срок кредита.");
                return false;
            }

            if (string.IsNullOrWhiteSpace(interestRateTextBox.Text) || !decimal.TryParse(interestRateTextBox.Text, out interestRate) || interestRate < 0)
            {
                MessageBox.Show("Введите корректную процентную ставку.");
                return false;
            }

            return true;
        }

        // Добавление нового типа кредита
        private void AddLoanTypeButton_Click(object sender, RoutedEventArgs e)
        {
            var newLoanType = new LoanType
            {
                LoanTypeName = "Новый тип кредита",
                MaxLoanAmount = 1000000,
                MinInterestRate = 5.0M,
                MaxInterestRate = 15.0M
            };

            db.LoanTypes.Add(newLoanType);
            db.SaveChanges();

            loanTypesGrid.ItemsSource = db.LoanTypes.Local.ToBindingList();
        }

        // Удаление выбранного типа кредита
        private void DeleteLoanTypeButton_Click(object sender, RoutedEventArgs e)
        {

            if (loanTypesGrid.SelectedItems.Count > 0)
            {
                for (int i = 0; i < loanTypesGrid.SelectedItems.Count; i++)
                {
                    var loanType = loanTypesGrid.SelectedItems[i] as LoanType;
                    if (loanType != null)
                    {
                        db.LoanTypes.Remove(loanType); // Удаляем выбранный тип кредита
                    }
                }

                db.SaveChanges(); // Сохраняем изменения в базе данных
                loanTypesGrid.ItemsSource = db.LoanTypes.Local.ToBindingList();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите тип кредита для удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void loansGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}